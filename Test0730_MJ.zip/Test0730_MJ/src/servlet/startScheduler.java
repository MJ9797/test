package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

import quartz.TestJob;


@WebServlet("/startScheduler")
public class startScheduler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    private static Scheduler scheduler;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            SchedulerFactory schedulerFactory = new StdSchedulerFactory();
            scheduler = schedulerFactory.getScheduler();
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	 try {
             if (scheduler != null && !scheduler.isStarted()) {
                 JobDataMap jobDataMap = new JobDataMap();
                 jobDataMap.put("jobSays", "Say Hello World!");
                 jobDataMap.put("myFloatValue", 3.1415f);
                 
                 JobDetail jobDetail = JobBuilder.newJob()
                     .withIdentity("myJob", "group1")
                     .setJobData(jobDataMap)
                     .build();
                 
                 CronTrigger cronTrigger = (CronTrigger) TriggerBuilder.newTrigger()
                     .withIdentity("triggerName", "cron_trigger_group")
                     .withSchedule(CronScheduleBuilder.cronSchedule("*/20 * * * * ?")) // 매 20초마다 실행
                     .forJob(jobDetail)
                     .build();
                 
                 scheduler.scheduleJob(jobDetail, cronTrigger);
                 scheduler.start();
             }
             response.setContentType("application/json");
             response.getWriter().write("{\"success\": true, \"message\": \"Scheduler started successfully.\"}");
         } catch (Exception e) {
             response.setContentType("application/json");
             response.getWriter().write("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
         }
	}

}
