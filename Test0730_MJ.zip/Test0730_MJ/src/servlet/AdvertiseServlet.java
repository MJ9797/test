package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;

import dao.MemberDao;


@WebServlet("/AdvertiseServlet")
public class AdvertiseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
        String id = (String) session.getAttribute("loginId");
        
        JSONObject jsonResponse = new JSONObject();
        Random rand = new Random();
        int points = rand.nextInt(1000) + 1; // 1 이상 1000 이하의 난수 발생
        
        if (id != null) {
            MemberDao memberDao = new MemberDao();
            try {
                // 사용자에게 포인트 적립
                boolean success = memberDao.addPoints(id, points);
                if (success) {
                    jsonResponse.put("success", true);
                    jsonResponse.put("message", points);
                } else {
                    jsonResponse.put("success", false);
                    jsonResponse.put("message", "포인트 적립에 실패했습니다.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                jsonResponse.put("success", false);
                jsonResponse.put("message", "서버 오류가 발생했습니다.");
            }
        } else {
            jsonResponse.put("success", false);
            jsonResponse.put("message", "로그인 정보가 없습니다."); 
        }
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.print(jsonResponse.toString());
        out.flush();
	}

}
