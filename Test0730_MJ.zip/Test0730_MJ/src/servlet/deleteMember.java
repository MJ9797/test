package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.MemberDao;


@WebServlet("/deleteMember")
public class deleteMember extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String memberId = request.getParameter("id");
        response.setContentType("application/json");
        try {
            MemberDao memberDao = new MemberDao();
            boolean success = memberDao.deleteMember(memberId); // 해당 회원 삭제 메서드 호출
            
            if (success) {
                response.getWriter().write("{\"success\": true, \"message\": \"회원이 삭제되었습니다.\"}");
            } else {
                response.getWriter().write("{\"success\": false, \"message\": \"회원 삭제에 실패했습니다.\"}");
            }
        } catch (Exception e) {
            response.getWriter().write("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
	}

}
