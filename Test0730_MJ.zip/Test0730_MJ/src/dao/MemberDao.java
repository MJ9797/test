package dao;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.MemberDto;

public class MemberDao {

	private static final ArrayList<MemberDto> listRet = null;

	// Connection getConnection() : Connection 객체를 리턴
	Connection getConnection() throws Exception {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String dbId = "user0625";
		String dbPw = "pass1234";

		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, dbId, dbPw);

		return conn;
	}

	// 멤버 id , name, pw, point
	public ArrayList<MemberDto> loginMember(String id) throws Exception {
		ArrayList<MemberDto> listRet = new ArrayList<MemberDto>();
	    Connection conn = getConnection(); 
	    
	    String sql = "SELECT id, name, pw, point FROM member WHERE id = ?";
	    PreparedStatement pstmt = conn.prepareStatement(sql);
	    pstmt.setString(1, id);
	    
	    ResultSet rs = pstmt.executeQuery(); // select문 실행
	    while (rs.next()) { 
	        String name = rs.getString("name"); 
	        String pw = rs.getString("pw"); 
	        int point = rs.getInt("point"); 
	        MemberDto dto = new MemberDto(id, name, pw, point); 
		 	listRet.add(dto);
	
	    }
	    
	    rs.close(); 
	    pstmt.close(); 
	    conn.close();
	    
	    return listRet; 
	}
	 

	public boolean loginCheck(String id, String pw) throws Exception {
		Connection conn = getConnection();

		String sql = "SELECT count(*) FROM member WHERE id=? AND pw=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, pw);

		ResultSet rs = pstmt.executeQuery(); // select문 실행
		int result = 0;
		if (rs.next()) {
			result = rs.getInt(1);
		}
		rs.close();
		pstmt.close();
		conn.close();

		return result == 1;
	}

	public void registerMember(String id, String pw, String name) throws Exception {
		Connection conn = getConnection();
		String sql = "INSERT INTO member(id, pw, name) VALUES(? ,? ,?)";

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, pw);
		pstmt.setString(3, name);

		pstmt.executeUpdate();

		pstmt.close();
		conn.close();

	}
	
	
    public ArrayList<MemberDto> getAllMembers() throws Exception {
        ArrayList<MemberDto> listRet = new ArrayList<MemberDto>(); 
        Connection conn = getConnection();
        
        String sql = "SELECT id, name, pw, point FROM member";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        
        ResultSet rs = pstmt.executeQuery(); // select문 실행
        
        while (rs.next()) { 
            String id = rs.getString("id");
            String name = rs.getString("name"); 
            String pw = rs.getString("pw"); 
            int point = rs.getInt("point"); 
            MemberDto dto = new MemberDto(id, name, pw, point); 
            listRet.add(dto);
        } 
        rs.close(); 
        pstmt.close(); 
        conn.close();
        
        return listRet; 
    }
    
    
    public boolean addPoints(String id, int points) throws Exception {
        Connection conn = getConnection();
        String sql = "UPDATE member SET point = point + ? WHERE id = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, points);
        pstmt.setString(2, id);
        
        int rowsUpdated = pstmt.executeUpdate();
        
        pstmt.close();
        conn.close();
        
        return rowsUpdated > 0; // 성공적으로 업데이트되면 true 반환
    }
    
    

    
    public boolean deleteMember(String id) throws Exception { 
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM member WHERE id = ?")) {
            
            pstmt.setString(1, id);
            int rowsAffected = pstmt.executeUpdate(); // 삭제된 행 수 반환
            
            return rowsAffected > 0; // 삭제가 성공적이었는지 확인
        } catch (Exception e) {
            // SQL 예외 처리
            e.printStackTrace();
            throw new Exception("회원 삭제 중 오류가 발생했습니다.", e);
        }
    }

}
