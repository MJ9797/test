package test;

import java.util.ArrayList;

import dao.MemberDao;
import dto.MemberDto;

public class Test {

	public static void main(String[] args) throws Exception {
		MemberDao dao = new MemberDao();
		
//		ArrayList<MemberDto>loginMember = dao.loginMember("ma");
//		for(MemberDto j : loginMember) { 
//			System.out.println(j);
//		}
		
		//dao.registerMember("MJ", "1234", "민지");
		
		//dao.addPoints("ma", 100);

	}

}
